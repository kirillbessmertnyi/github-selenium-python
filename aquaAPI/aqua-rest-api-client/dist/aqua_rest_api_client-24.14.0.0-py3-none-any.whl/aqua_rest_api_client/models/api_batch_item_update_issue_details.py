from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.api_batch_item_update_issue_details_type import ApiBatchItemUpdateIssueDetailsType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ApiBatchItemUpdateIssueDetails")


@attr.s(auto_attribs=True)
class ApiBatchItemUpdateIssueDetails:
    """
    Attributes:
        details_type (str):
        type (Union[Unset, ApiBatchItemUpdateIssueDetailsType]): Represents reason of a failure of batch-item update
            operation
            This enum has the following values:
              - `Denied` Access to the item has been denied
              - `Failure` Uncategorized failure
              - `FieldIncompatible` A field could not be converted due to incompatibility
              - `Locked` Item was currently edited by someone
              - `NotFound` Item has not been found
              - `ValueNotAllowed` When updating an item, the given value was not allowed (e.g. due to format, length, denied
            by workflow rules etc.)
    """

    details_type: str
    type: Union[Unset, ApiBatchItemUpdateIssueDetailsType] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        details_type = self.details_type
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = self.type.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "DetailsType": details_type,
            }
        )
        if type is not UNSET:
            field_dict["Type"] = type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        details_type = d.pop("DetailsType")

        _type = d.pop("Type", UNSET)
        type: Union[Unset, ApiBatchItemUpdateIssueDetailsType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = ApiBatchItemUpdateIssueDetailsType(_type)

        api_batch_item_update_issue_details = cls(
            details_type=details_type,
            type=type,
        )

        api_batch_item_update_issue_details.additional_properties = d
        return api_batch_item_update_issue_details

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
